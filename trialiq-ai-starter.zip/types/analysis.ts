export interface AnalysisResult {}
